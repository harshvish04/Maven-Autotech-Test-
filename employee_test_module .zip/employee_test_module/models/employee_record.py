from odoo import models, fields, api
from datetime import date
from odoo.exceptions import ValidationError

class EmployeeRecord(models.Model):
    _name = 'employee.record'
    _description = 'Employee Record'
    _sql_constraints = [
        ('unique_char_field', 'unique(field_char)', 'Char field must be unique.')
    ]

    field_char = fields.Char("Char Field")
    field_text = fields.Text("Text Field")
    field_integer = fields.Integer("Integer Field")
    field_float = fields.Float("Float Field")
    field_boolean = fields.Boolean("Boolean Field")
    field_date = fields.Date("Date Field")
    field_datetime = fields.Datetime("Datetime Field")
    field_selection = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Gender")
    field_binary = fields.Binary("Upload File")
    field_html = fields.Html("HTML Description")

    field_many2one = fields.Many2one('res.partner', string="Related Partner")
    field_many2many = fields.Many2many('res.partner', string="Many Partners")
    field_one2many = fields.One2many('employee.task.line', 'employee_id', string="Tasks")

    country_ids = fields.Many2many('res.country', string="Related Countries")

    computed_age = fields.Integer(string="Age", compute="_compute_age")
    auto_updated_char = fields.Char("Auto Updated")

    @api.onchange('field_selection')
    def _onchange_gender(self):
        if self.field_selection == 'male':
            self.auto_updated_char = "Updated to Male"
        elif self.field_selection == 'female':
            self.auto_updated_char = "Updated to Female"

    @api.depends('field_date')
    def _compute_age(self):
        for rec in self:
            if rec.field_date:
                rec.computed_age = date.today().year - rec.field_date.year
            else:
                rec.computed_age = 0

    @api.constrains('field_date')
    def _check_date_not_future(self):
        for rec in self:
            if rec.field_date and rec.field_date > date.today():
                raise ValidationError("Date cannot be in the future.")

    def action_populate_fields(self):
        for rec in self:
            rec.update({
                'field_selection': 'male',
                'field_char': 'Populated Char',
                'field_integer': 99,
            })

class EmployeeTaskLine(models.Model):
    _name = 'employee.task.line'
    _description = 'Employee Task Line'

    name = fields.Char("Task Name")
    employee_id = fields.Many2one('employee.record', string="Employee")
