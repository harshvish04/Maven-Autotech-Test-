from odoo import models, fields

class StockPickingBatch(models.Model):
    _inherit = 'stock.picking.batch'

    custom_batch_note = fields.Text(string='Custom Batch Note')
