from odoo import models, fields

class ResCountry(models.Model):
    _inherit = 'res.country'

    custom_field = fields.Char(string="Custom Field")

