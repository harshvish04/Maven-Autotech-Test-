{
    'name': 'Employee Test Module',
    'version': '1.0',
    'depends': ['base', 'hr', 'stock', 'sale', 'stock_picking_batch'],
    'author': 'Test Developer',
    'category': 'Custom',
    'description': """
    Custom test module for Odoo developer technical test.
    """,
    'data': [
        'security/ir.model.access.csv',
        'views/employee_record_views.xml',
        'views/res_country_extension.xml',
        'views/stock_picking_batch_inherit.xml',
        'views/sale_order_kanban_inherit.xml',
        'report/report_deliveryslip_inherit.xml',
    ],
    'installable': True,
    'application': True,
}
